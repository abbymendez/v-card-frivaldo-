import React, {useState} from 'react';
import { View, Image, ScrollView, Text, SafeAreaView, Linking, TouchableOpacity, TextInput, StyleSheet } from 'react-native';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { FontAwesome5 } from '@expo/vector-icons';


export default function Vcard () { 

  const accs = (url) => {
    Linking.openURL(url).catch((err) => console.error("Failed to open URL:", err));
  };

  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [isTimePickerVisible, setTimePickerVisibility] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };
  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };
  const showTimePicker = () => {
    setTimePickerVisibility(true);
  };
  const hideTimePicker = () => {
    setTimePickerVisibility(false);
  };
  const handleDateConfirm = (date) => {
    setSelectedDate(date.toISOString().split('T')[0]);
    hideDatePicker();
  };
  const handleTimeConfirm = (time) => {
    setSelectedTime(time.toLocaleTimeString());
    hideTimePicker();
  };

  const [value1, change1] = React.useState('');
  const [value2, chang2] = React.useState('');
  const [value3, change3] = React.useState('');
  const [w, setW] = useState(195);
  const [h, setH] = useState(110);
  const [w2, setW2] = useState(195);
  const [h2, setH2] = useState(110);
  const [w3, setW3] = useState(195);
  const [h3, setH3] = useState(110);
  const [w4, setW4] = useState(195);
  const [h4, setH4] = useState(110);

  const onClick = () => {
    if (w == 295)
    {
      setW(195);
    }

    if (h == 210)
    {
      setH(110);
    }

    if (h == 110) {
      const wid = w + 100;
      const heig = h + 100;

      setW(wid);
      setH(heig);
    }
  };

  const onClick2 = () => {
    if (w2 == 295)
    {
      setW2(195);
    }

    if (h2 == 210)
    {
      setH2(110);
    }

    if (h2 == 110) {
      const wid2 = w2 + 100;
      const heig2 = h2 + 100;

      setW2(wid2);
      setH2(heig2);
    }
  };

  const onClick3 = () => {
    if (w3 == 295)
    {
      setW3(195);
    }

    if (h3 == 210)
    {
      setH3(110);
    }

    if (h3 == 110) {
      const wid3 = w3 + 100;
      const heig3 = h3 + 100;

      setW3(wid3);
      setH3(heig3);
    }
  };

  const onClick4 = () => {
    if (w4 == 295)
    {
      setW4(195);
    }

    if (h4 == 210)
    {
      setH4(110);
    }

    if (h4 == 110) {
      const wid4 = w4 + 100;
      const heig4 = h4 + 100;

      setW4(wid4);
      setH4(heig4);
    }
  };

  return(
    <SafeAreaView style={Styles.container}>
    <ScrollView>

     <View style={Styles.backContainer}>
        <Image
          style={Styles.backPhoto}
          source={require('./assets/picture.jpg')}
        />
        <View style={Styles.imgContainer}>
          <Image
            style={Styles.myImage}
            source={require('./assets/me.jpg')}
          />
          <Text style={Styles.name}>ABEGAIL BENOSA FRIVALDO</Text>
          <Text style={Styles.sub}>BS Information Technology</Text>
          <Text style={Styles.sub}>Global Reciprocal College</Text>
        </View>
      </View>

      <View style={Styles.aboutMe}>
        <Text style={Styles.sub}> I'm currently college student and practicing and enhance my skills and I want learn more about programming and picture and video editing. Because I consider myself a Responsible, Hardworking and learn a lot more about computers.
        </Text>
      </View>

      <View style={Styles.infos}>
        <View style={Styles.accs}>
        <TouchableOpacity 
          onPress={( ) => accs('https://www.facebook.com/abegail.frivaldo19')}>
        <FontAwesome5 
          name="facebook"
          size={25}
          color="#273c39"
          style={Styles.icon} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => accs('https://www.instagram.com/abegailfrivaldo')}>
          <FontAwesome5
            name="instagram"
            size={25}
            color="#273c39"
            style={Styles.icon} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => accs('https://www.tiktok.com/@abbhiee.e')}>
          <FontAwesome5
            name="tiktok"
            size={25}
            color="#273c39"
            style={Styles.icon} />
        </TouchableOpacity>
      </View>
        <View style={Styles.border}>
        <View style={Styles.box}>
          <FontAwesome5
            name="envelope"
            size={25}
            color="#273c39"
            style={Styles.icon} />
          <Text style={Styles.access}>frivaldoabegail07@gmail.com</Text>
        </View>
        <View style={Styles.box}>
          <FontAwesome5
            name="phone"
            size={25}
            color="#273c39"
            style={Styles.icon} />
          <Text style={Styles.access}>09101403936</Text>
        </View>
        </View>
        <View style={Styles.border}>
          <View style={Styles.box}>
            <FontAwesome5
              name="birthday-cake"
              size={25}
              color="#273c39"
              style={Styles.icon} />
            <Text style={Styles.access}>06-19-2002</Text>
          </View>
          <View style={Styles.box}>
            <FontAwesome5
              name="map-marker"
              size={25}
              color="#273c39"
              style={Styles.icon} />
            <Text style={Styles.access}>Valenzuela City</Text>
          </View>
        </View>
      </View>

      <View style={Styles.appointment}>
        <Text style={Styles.titles}>MAKE AN APPOINTMENT</Text>
          <View style={Styles.label}>
            <Text style={Styles.sub}>Date:</Text>
            <TouchableOpacity onPress={showDatePicker}>
              <Text style={Styles.datePickerText}>{selectedDate || 'set date'}</Text>
            </TouchableOpacity>
            <DateTimePickerModal
              isVisible={isDatePickerVisible}
              mode="date"
              onConfirm={handleDateConfirm}
              onCancel={hideDatePicker}
                />
            </View>
            <View>
              <Text style={Styles.sub}>Time</Text>
              <View style={Styles.hour}>
                <TouchableOpacity onPress={showTimePicker}>
                  <Text style={Styles.timePickerText}>{selectedTime || 'set time'}</Text>
                </TouchableOpacity>
                <DateTimePickerModal
                  isVisible={isTimePickerVisible}
                  mode="time"
                  onConfirm={handleTimeConfirm}
                  onCancel={hideTimePicker}
                />
              </View>
              <View style={Styles.btn}>
                <TouchableOpacity style={Styles.submit}>
                  <Text style={Styles.btnTxt}>Make an Appointment</Text>
                </TouchableOpacity>
              </View>
            </View>
      </View>

      <View>
        <Text style={Styles.titles}>GALLERY </Text>
        <View style={Styles.galleryContainer}>
          <TouchableOpacity onPress={onClick}>
            <Image
            style={{
              width: w,
              height: h,
              borderWidth: 3,
              borderColor: '#273c39',
              borderRadius: 10, 
            }}
            source={require('./assets/pic1.png')}
          />
          </TouchableOpacity>
          <TouchableOpacity onPress={onClick2}>
            <Image
            style={{
              width: w2,
              height: h2,
              borderWidth: 3,
              borderColor: '#273c39',
              borderRadius: 10, 
            }}
            source={require('./assets/pic2.jpg')}
          />
          </TouchableOpacity>
        </View>
        <View style={Styles.galleryContainer}>
          <TouchableOpacity onPress={onClick3}>
           <Image
            style={{
              width: w3,
              height: h3,
              borderWidth: 3,
              borderColor: '#273c39',
              borderRadius: 10, 
            }}
            source={require('./assets/pic3.jpg')}
          />
          </TouchableOpacity>
          <TouchableOpacity onPress={onClick4}>
            <Image
            style={{
              width: w4,
              height: h4,
              borderWidth: 3,
              borderColor: '#273c39',
              borderRadius: 10, 
            }}
            source={require('./assets/pic4.jpg')}
          />
          </TouchableOpacity>
        </View>
      </View>

      <View style={Styles.contact}>
        <Text style={Styles.titles}>Countact Us!</Text>
          <TextInput
              style={Styles.input}
              onChangeText={change1}
              value={value1}
              placeholder="Name"
            />
          <TextInput
              style={Styles.input}
              onChangeText={chang2}
              value={value2}
              placeholder="Email"
            />
          <TextInput
              style={Styles.input}
              editable
              multiline
              numberOfLines={3}
              maxLength={30}
              onChangeText={text => change3(text)}
              value={value3}
              placeholder="Type your message here."
            />
            <View style={Styles.btn}>
              <TouchableOpacity style={Styles.submit}>
                <Text style={Styles.btnTxt}>Send Message</Text>
              </TouchableOpacity>
            </View>
      </View>
     </ScrollView>
     </SafeAreaView>
  );
}

const Styles = StyleSheet.create({
  
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#e9f6ef',
  },
  backContainer: {
    alignItems: 'center',
  },
  backPhoto: {
    width: '100%',
    height: 180,
  },
  imgContainer: {
    alignItems: 'center',
    marginTop: -70,
  },
  myImage: {
    width: 120,
    height: 120,
    borderRadius: 80,
    borderColor: '#e0ffff' ,
    borderWidth: 5,
  },
  name:{
    fontSize: 20,
    fontWeight: 'bold',
  },
  titles: {
    fontSize: 18,
    fontWeight: 'bold',
    color:"#273c39",
    textAlign: 'center'
  },
  sub: {
    fontSize: 14,
    color: '#656565',
    textAlign: 'center'
  },
  accs:{
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: '#cfe9e4',
    margin: 2,
  },
  icon:{
    padding: 20,
  },
  aboutMe: {
    margin: 20,
  },
  infos: {
    margin: 10,
  },
  access:{
    color: '#273c39',
    fontSize: 16,
    textAlign: 'center'
  },
  border:{
    flexDirection: 'row',
    justifyContent: 'center'
  },
  box:{
    padding: 5,
    backgroundColor: '#cfe9e4',
    justifyContent: 'start',
    alignItems: 'center',
    margin: 2,
    width: '50%'
  },
  appointment:{
    margin: 20,
  },
  datePickerText:{
    borderWidth: 1,
    padding: 10,
    textAlign: 'center'
  },
  label:{
    marginTop: 20,
  },
  hour:{
    flexDirection:'row',
    borderWidth: 1,
    padding: 10,
    justifyContent: 'center'
  },
  timePickerText:{
    textAlign: 'center'
  },
  btn:{
    alignItems: 'center',
    marginTop: 5,
    marginBottom:20,
  },
  galleryContainer: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
  margin: 5,
},
images: {
  width: '48%', 
  aspectRatio: 16 / 9, 
  borderWidth: 3,
  borderColor: '#273c39',
  borderRadius: 10, 
},
  contact:{
    marginTop:20,
    padding:20
  },
  input:{
    borderWidth: 1,
    padding: 10,
    backgroundColor: 'white',
    textAlign: 'start',
    margin:5
  },
  submit:{
    backgroundColor: '#273c39',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    marginTop: 10,
    width: '50%'
  },
  btnTxt:{
    color: '#cfe9e4',
    fontSize: 14,
    textAlign: 'center',
    fontWeight: 'bold',
  },

})
